import numpy as np
import pandas as pd
import time  # 用于计算时间
from random import randint, uniform

# 商品分类
categories = ["Cauliflower", "Leafy flowers", "Peppers", "Solanaceae", "Mushrooms", "Aquatic roots and tubers"]

# 定义需求量公式参数（基于回归结果）
parameters = {
    "Cauliflower": {"alpha": 2.1886, "beta": -0.9857, "gamma": {"Solanaceae": 0.5908},
                    "delta": {"Mushrooms": 0.4195, "Leafy flowers": 0.4908}},
    "Leafy flowers": {"alpha": 3.1204, "beta": -0.6574, "gamma": {"Cauliflower": 0.3061},
                      "delta": {"Peppers": 0.2717, "Mushrooms": 0.3482, "Cauliflower": 0.2072}},
    "Peppers": {"alpha": 3.2775, "beta": -0.5992, "gamma": {"Mushrooms": 0.2702},
                "delta": {"Mushrooms": 0.5095, "Solanaceae": 0.1585, "Cauliflower": 0.1067}},
    "Solanaceae": {"alpha": -2.9685, "beta": 0, "gamma": {"Cauliflower": 0.5727},
                   "delta": {"Peppers": 0.6752, "Mushrooms": 0.4111}},
    "Mushrooms": {"alpha": -0.4126, "beta": -0.3457, "gamma": {"Peppers": 0.5006},
                  "delta": {"Peppers": 0.7163, "Leafy flowers": 0.3453}},
    "Aquatic roots and tubers": {"alpha": -0.9428, "beta": 0, "gamma": {"Leafy flowers": -1.5807, "Solanaceae": 0.7967},
                                 "delta": {"Peppers": 1.0462}}
}

# 每日成本、损耗率和需求量
future_costs = pd.DataFrame({
    "Cauliflower": [8.25, 8.15, 8.09, 8.09, 8.17, 8.01, 8.13, 8.07, 8.28, 8.14, 8.22, 8.27, 8.14, 8.20, 8.24],
    "Leafy flowers": [5.13, 5.29, 5.31, 5.31, 5.41, 5.30, 5.47, 5.23, 5.30, 5.23, 5.46, 5.35, 5.33, 5.33, 5.37],
    "Peppers": [6.26, 6.27, 6.29, 6.26, 6.41, 6.43, 6.45, 6.41, 6.46, 6.43, 6.39, 6.46, 6.43, 6.38, 6.43],
    "Solanaceae": [5.37, 5.11, 5.26, 5.20, 5.13, 5.10, 5.01, 5.12, 4.89, 4.97, 5.03, 5.14, 4.99, 5.16, 4.92],
    "Mushrooms": [7.71, 7.71, 7.66, 7.71, 7.49, 7.64, 7.56, 7.56, 7.42, 7.47, 7.48, 7.58, 7.45, 7.58, 7.58],
    "Aquatic roots and tubers": [8.86, 8.72, 8.80, 8.46, 8.77, 8.56, 8.68, 8.41, 8.40, 8.34, 8.53, 8.48, 8.49, 8.45, 8.33]
})

future_sales = pd.DataFrame({
    "Cauliflower": [57.71, 60.01, 50.15, 49.40, 57.75, 48.71, 51.86, 41.90, 48.34, 45.01, 44.55, 43.29, 48.67, 45.91, 44.16],
    "Leafy flowers": [214.25, 222.83, 208.45, 210.53, 216.03, 214.79, 234.68, 209.97, 207.39, 209.48, 211.89, 202.14, 207.88, 195.66, 198.93],
    "Peppers": [75.91, 83.59, 99.30, 92.10, 110.31, 111.15, 115.29, 77.60, 79.22, 86.86, 88.42, 82.20, 74.76, 75.75, 73.53],
    "Solanaceae": [29.73, 28.93, 30.87, 30.79, 30.48, 31.55, 35.94, 27.80, 27.41, 29.72, 30.21, 28.53, 26.49, 26.82, 26.57],
    "Mushrooms": [64.39, 67.26, 61.32, 68.49, 81.01, 80.93, 90.87, 58.11, 65.90, 71.52, 67.51, 63.59, 66.01, 66.12, 58.49],
    "Aquatic roots and tubers": [23.24, 25.31, 22.09, 31.21, 28.50, 42.94, 50.70, 21.60, 23.34, 20.92, 21.29, 19.70, 27.55, 27.31, 24.76]
})

loss_rate = pd.Series({
    "Cauliflower": 0.1551,
    "Leafy flowers": 0.1283,
    "Peppers": 0.0924,
    "Solanaceae": 0.0668,
    "Mushrooms": 0.0945,
    "Aquatic roots and tubers": 0.1365
})


# 定义需求函数
def demand_function(category, costs, sales, markups):
    param = parameters[category]
    p_i = costs[category] * (1 + markups[category])
    gamma_part = sum(
        param["gamma"].get(other, 0) * np.log(costs[other] * (1 + markups[other])) for other in categories if
        other != category)
    delta_part = sum(param["delta"].get(other, 0) * np.log(sales[other]) for other in categories if other != category)
    demand = np.exp(param["alpha"] - param["beta"] * np.log(p_i) + gamma_part + delta_part)
    return demand


# 目标函数
def objective(vars, *args):
    categories, costs, sales = args
    Q, m = vars[:len(categories)], vars[len(categories):]
    revenue = sum((costs[cat] * (1 + m[i]) - costs[cat]) * min(Q[i], sales[cat]) for i, cat in enumerate(categories))
    holding_cost = sum(loss_rate[cat] * (Q[i] - sales[cat]) for i, cat in enumerate(categories))
    penalty = sum(2000 * max(0, m[i] - 0.35) ** 2 for i in range(len(categories)))  # 惩罚过高的加成率
    return -(revenue - holding_cost - penalty)  # 最大化利润


# 禁忌搜索法（Tabu Search）
def optimize_day(costs, sales):
    lb = [sales[cat] for cat in categories] + [0.05 for _ in categories]
    ub = [sales[cat] * 1.5 for cat in categories] + [0.5 for _ in categories]

    # 初始解
    current_solution = [uniform(lb[i], ub[i]) for i in range(len(lb))]
    best_solution = current_solution[:]
    best_value = objective(current_solution, categories, costs, sales)

    # 禁忌表
    tabu_list = []

    # 定义搜索的参数
    max_iterations = 100  # 最大迭代次数
    tenure = 5  # 禁忌表的持续期
    neighborhood_size = 5  # 邻域大小

    start_time = time.time()  # 开始计时

    for iteration in range(max_iterations):
        neighborhood = []

        # 生成邻域解
        for _ in range(neighborhood_size):
            neighbor = current_solution[:]
            index = randint(0, len(neighbor) - 1)
            step = uniform(-0.1, 0.1)
            neighbor[index] = min(max(neighbor[index] + step, lb[index]), ub[index])
            neighborhood.append(neighbor)

        # 评估邻域解
        best_neigh = None
        best_neigh_value = float('inf')

        for neigh in neighborhood:
            if neigh not in tabu_list:
                neigh_value = objective(neigh, categories, costs, sales)
                if neigh_value < best_neigh_value:
                    best_neigh = neigh
                    best_neigh_value = neigh_value

        # 更新禁忌表
        tabu_list.append(current_solution)
        if len(tabu_list) > tenure:
            tabu_list.pop(0)

        # 更新当前解
        current_solution = best_neigh
        current_value = best_neigh_value

        # 更新全局最优解
        if current_value < best_value:
            best_solution = current_solution
            best_value = current_value

    end_time = time.time()  # 结束计时
    elapsed_time = end_time - start_time
    print(f"优化时间: {elapsed_time:.2f}秒")  # 输出时间

    Q_opt = best_solution[:len(categories)]
    m_opt = best_solution[len(categories):]

    result_data = {
        "Optimal Quantities": dict(zip(categories, Q_opt)),
        "Optimal Markups": dict(zip(categories, m_opt)),
        "Prices": {cat: costs[cat] * (1 + m) for cat, m in zip(categories, m_opt)},
        "Profit": -best_value
    }
    return result_data


# 逐天优化并存储结果
results = []
for day in range(len(future_sales)):
    costs = future_costs.iloc[day].to_dict()
    sales = future_sales.iloc[day].to_dict()
    daily_result = optimize_day(costs, sales)
    daily_result["Date"] = day + 1
    results.append(daily_result)

# 输出为DataFrame并保存
df_quantities = pd.DataFrame([{**{"Date": r["Date"]}, **r["Optimal Quantities"]} for r in results])
df_markups = pd.DataFrame([{**{"Date": r["Date"]}, **r["Optimal Markups"]} for r in results])
df_prices_profit = pd.DataFrame([{**{"Date": r["Date"]}, **r["Prices"], "Profit": r["Profit"]} for r in results])

output_file = "Tabu_Search_optimization_results.xlsx"
with pd.ExcelWriter(output_file) as writer:
    df_quantities.to_excel(writer, sheet_name="Optimal Quantities", index=False)
    df_markups.to_excel(writer, sheet_name="Optimal Markups", index=False)
    df_prices_profit.to_excel(writer, sheet_name="Prices and Profit", index=False)

print(f"结果已保存到文件：{output_file}")
