import pandas as pd
from sklearn.impute import KNNImputer

# 要处理的文件列表
files = ["销量_twoyear.xlsx", "销售价格_twoyear.xlsx", "补货价格_twoyear.xlsx"]

for file in files:
    print(f"正在处理 {file} ...")
    df = pd.read_excel(file)

    # 确认数据列
    print("原始缺失值统计：")
    print(df.isna().sum())

    # 取出除日期以外的数值列
    date_col = df.iloc[:, 0]   # 第一列是“销售日期”
    values = df.iloc[:, 1:]    # 其余列是数值

    # KNN 插值
    imputer = KNNImputer(n_neighbors=5, weights="uniform")
    values_filled = imputer.fit_transform(values)

    # 还原为 DataFrame
    df_filled = pd.DataFrame(values_filled, columns=values.columns)
    df_filled.insert(0, "销售日期", date_col)

    # 保存
    out_file = file.replace(".xlsx", "_filled.xlsx")
    df_filled.to_excel(out_file, index=False)
    print(f"已保存为 {out_file}\n")
