# -*- coding: utf-8 -*-
"""
原始均值 ± 95% CI 可视化（不做任何数据变换）
- 全局字体：Times New Roman（解决 SimHei 无“²”字形的问题）
- R² 使用数学公式 r"$R^2$" 渲染，确保上标显示
- 英文标签：提供单行与两行两套可选
- 可选修正：花叶类 sMAPE 的 CI=7031 -> 0.7031（若确为笔误）
- 导出 PNG / PDF
"""

import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

# =============== 配置 ===============
# 若确认“花叶类 sMAPE 的 CI=7031”为笔误，把它修正为 0.7031
FIX_SMAPE_TYPO = True
# 使用两行英文标签（True）或单行（False）
USE_TWO_LINE = True
# 图像文件名前缀
OUT_PREFIX = "metrics_raw_CI_subplots_en"

# —— 全局字体改为 Times New Roman（含上标²） ——
plt.rcParams["font.family"] = "serif"
plt.rcParams["font.serif"] = ["Times New Roman"]
plt.rcParams["axes.unicode_minus"] = False  # 避免负号乱码

# =============== 你的原始数据（均值±95%CI） ===============
data = {
    "数据集": ["花菜类","花叶类","辣椒类","茄类","食用菌","水生根茎类"],
    "R2":      ["0.9611±0.0087","0.9116±0.0278","0.9481±0.0133","0.9517±0.0264","0.9621±0.0137","0.9597±0.0367"],
    "MASE":    ["0.1513±0.0280","0.1350±0.0272","0.1238±0.0170","0.0861±0.0244","0.0844±0.0184","0.0828±0.0271"],
    "MAPE(%)": ["0.9432±0.1246","3.3089±0.8278","1.3691±0.1993","1.0169±0.3163","1.4002±0.2602","1.1446±0.4066"],
    "sMAPE(%)":["0.9150±0.1157","3.0613±7031","1.3143±0.1842","1.0092±0.3074","1.3947±0.2493","1.1885±0.4665"],
}
df = pd.DataFrame(data)

# =============== 英文标签映射（单行 & 两行） ===============
label_map_single = {
    "花菜类":     "Cauliflower",
    "花叶类":     "Leafy Greens",
    "辣椒类":     "Peppers",
    "茄类":       "Solanaceous Vegetables",
    "食用菌":     "Mushrooms",
    "水生根茎类": "Aquatic Roots and Tubers",
}
label_map_two_line = {
    "花菜类":     "Cauliflower",
    "花叶类":     "Leafy\nGreens",
    "辣椒类":     "Peppers",
    "茄类":       "Solanaceous\nVegetables",
    "食用菌":     "Mushrooms",
    "水生根茎类": "Aquatic Roots\nand Tubers",
}
label_map = label_map_two_line if USE_TWO_LINE else label_map_single
df["Label_EN"] = df["数据集"].map(label_map).fillna(df["数据集"])

# =============== 解析 "mean±ci" ===============
def split_mean_ci(series):
    means, cis = [], []
    for s in series:
        if "±" in s:
            m, c = s.split("±")
            means.append(float(m))
            cis.append(float(c))
        else:
            means.append(float(s))
            cis.append(0.0)
    return np.array(means), np.array(cis)

# 可选：修正花叶类 sMAPE 的疑似笔误
if FIX_SMAPE_TYPO:
    idx = df.index[df["数据集"] == "花叶类"]
    if len(idx) > 0:
        i = idx[0]
        smape_str = df.at[i, "sMAPE(%)"]
        if "±" in smape_str:
            m, c = smape_str.split("±")
            try:
                c_val = float(c)
                if c_val > 100:  # 很可能写成了 7031
                    df.at[i, "sMAPE(%)"] = f"{m}±{c_val/10000.0:.4f}"
            except ValueError:
                pass

# =============== 绘图（原始均值 ± 95%CI；不做任何变换） ===============
metrics = [("R2", r"$R^2$"), ("MASE","MASE"), ("MAPE(%)","MAPE (%)"), ("sMAPE(%)","sMAPE (%)")]
fig, axes = plt.subplots(1, 4, figsize=(28, 6))
axes = axes.ravel()
x = np.arange(len(df))

for ax, (col, label) in zip(axes, metrics):
    means, cis = split_mean_ci(df[col])
    # 误差线：均值 ± 95%CI（按原值展示）
    ax.errorbar(x, means, yerr=cis, fmt='o', capsize=4)
    # 英文类目标签
    ax.set_xticks(x)
    ax.set_xticklabels(df["Label_EN"].tolist(), rotation=0)
    # 子图标题（R² 用数学公式）
    ax.set_title(label)
    # 网格
    ax.grid(True, axis='y', linestyle='--', alpha=0.4)
    # 在点上方标注“均值±CI”
    for i, (m, c) in enumerate(zip(means, cis)):
        ax.text(i, m, f"{m:.3f}±{c:.3f}", ha="center", va="bottom", fontsize=8)

# 总标题（含数学公式、±）
plt.tight_layout()

# 保存文件（PNG+PDF）
plt.show()
