# -*- coding: utf-8 -*-
"""
MBB稳健性：对 10% / 50% / 100% 的有效样本长度做移动块自助，
在每次重采样上拟合 逐步回归 / LASSO / 岭回归，
把每次抽样的 AIC/BIC 结果写入 Excel。

依赖:
  pandas, numpy, statsmodels, scikit-learn, openpyxl
"""

import os
import math
import numpy as np
import pandas as pd
from typing import List, Tuple, Dict

import statsmodels.api as sm
from sklearn.linear_model import LassoCV, RidgeCV, Ridge
from sklearn.preprocessing import StandardScaler

# ============== 配置区 ==============
DATA_FILE = r'C:\Users\15549\Desktop\问题一合并后的数据(仅供参考) - 副本.xlsx'
SELLING_PRICE_SHEET = "销售单价"
WHOLESALE_PRICE_SHEET = "批发价格"
SALES_VOLUME_SHEET = "销量"

CATEGORIES = [
    'Cauliflower', 'Leafy Greens', 'Peppers',
    'Solanaceous Vegetables', 'Mushrooms', 'Aquatic Roots and Tubers'
]

# 抽样比例 & 重复次数
R_LIST = [0.5, 0.7, 1.0]
B = 100                  # 每个比例的重采样次数
RANDOM_SEED = 2025       # 随机种子
np.random.seed(RANDOM_SEED)

# 输出
OUTPUT_EXCEL = "robustness_MBB_AIC_BIC.xlsx"

# ============== 工具函数 ==============

def safe_log_series(s: pd.Series, eps: float = 1e-8) -> pd.Series:
    """避免非正数取对数报错：把<=0的替换为很小的正数。"""
    s = s.copy()
    s = s.astype(float)
    s[s <= 0] = eps
    return np.log(s)

def build_design_matrices(selling_price: pd.DataFrame,
                          wholesale_price: pd.DataFrame,
                          sales_volume: pd.DataFrame,
                          category: str) -> Tuple[pd.Series, pd.DataFrame]:
    """按你的口径构造 y=log(销量[category])，X 含本类的 log(批发价*(1+销售价)) 和其他品类的 log(销售价/销量)。"""
    y = safe_log_series(sales_volume[category])

    X = pd.DataFrame(index=y.index)
    # 本类组合项
    X['Wholesale Price * Markup'] = safe_log_series(wholesale_price[category] * (1.0 + selling_price[category]))
    # 其他品类
    for other in CATEGORIES:
        if other == category:
            continue
        X[f'Selling Price ({other})'] = safe_log_series(selling_price[other])
        X[f'Sales Volume ({other})']   = safe_log_series(sales_volume[other])

    # 去掉出现NaN/inf的行（理论上 safe_log 后不应有）
    valid_idx = X.replace([np.inf, -np.inf], np.nan).dropna().index.intersection(
        y.replace([np.inf, -np.inf], np.nan).dropna().index
    )
    X = X.loc[valid_idx].copy()
    y = y.loc[valid_idx].copy()
    return y, X

def ols_fit(y: pd.Series, X: pd.DataFrame) -> sm.regression.linear_model.RegressionResultsWrapper:
    """带截距的 OLS 拟合。"""
    Xc = sm.add_constant(X, has_constant='add')
    model = sm.OLS(y, Xc).fit()
    return model

def aic_bic_from_rss(n: int, rss: float, k: float) -> Tuple[float, float]:
    """基于高斯似然的 AIC/BIC（k 可为有效自由度；包含截距）。"""
    if n <= 0:
        return np.nan, np.nan
    sigma2 = rss / n
    if sigma2 <= 0:
        # 极端情况下保护
        sigma2 = 1e-12
    aic = n * np.log(sigma2) + 2.0 * k
    bic = n * np.log(sigma2) + np.log(n) * k
    return float(aic), float(bic)

def mbb_indices(T: int, target_len: int, block_len: int) -> np.ndarray:
    """Moving Block Bootstrap: 从长度为 T 的序列中，有放回地抽若干长度为 block_len 的连续块，拼接到 target_len。"""
    if block_len <= 0:
        block_len = 1
    starts = np.random.randint(0, T - block_len + 1, size=math.ceil(target_len / block_len))
    idx_list = []
    for s in starts:
        idx_list.extend(range(s, s + block_len))
        if len(idx_list) >= target_len:
            break
    return np.array(idx_list[:target_len], dtype=int)

def suggest_block_len(T: int) -> int:
    """经验块长：T^(1/3) 向上取整（可根据需要调参/敏感性分析）。"""
    return max(2, int(np.ceil(T ** (1/3))))

# ============== 逐步回归（BIC） ==============

def stepwise_bic(y: pd.Series, X: pd.DataFrame, max_iter: int = 200) -> Tuple[List[str], sm.regression.linear_model.RegressionResultsWrapper]:
    """
    简易前进-后退逐步（以BIC为准则）。
    返回：入模变量列表、最终OLS模型
    """
    remaining = set(X.columns)
    selected: List[str] = []
    current_bic = np.inf
    improved = True
    iter_cnt = 0

    while improved and iter_cnt < max_iter:
        iter_cnt += 1
        improved = False

        # 尝试前进：逐一尝试把一个候选加入
        best_candidate = None
        best_bic = current_bic

        for cand in list(remaining):
            try_vars = selected + [cand]
            model = ols_fit(y, X[try_vars])
            bic = model.bic
            if bic < best_bic - 1e-10:
                best_bic = bic
                best_candidate = cand

        if best_candidate is not None:
            selected.append(best_candidate)
            remaining.remove(best_candidate)
            current_bic = best_bic
            improved = True

            # 后退一步：检查已入模变量是否有可剔除的
            removed_any = True
            while removed_any:
                removed_any = False
                best_bic_remove = current_bic
                remove_target = None
                for var in list(selected):
                    trial_vars = [v for v in selected if v != var]
                    if len(trial_vars) == 0:
                        continue
                    model = ols_fit(y, X[trial_vars])
                    bic = model.bic
                    if bic < best_bic_remove - 1e-10:
                        best_bic_remove = bic
                        remove_target = var
                if remove_target is not None:
                    selected.remove(remove_target)
                    remaining.add(remove_target)
                    current_bic = best_bic_remove
                    removed_any = True

    # 最终拟合
    if len(selected) == 0:
        # 无变量时用截距项模型
        model = ols_fit(y, X.iloc[:, :0])  # 空X
    else:
        model = ols_fit(y, X[selected])
    return selected, model

# ============== LASSO（CV 选 λ） + Post-OLS(AIC/BIC) ==============

def lasso_post_ols(
    y: pd.Series, X: pd.DataFrame,
    alphas: np.ndarray = None,
    cv: int = 5,
    tol: float = 1e-4,            # 放宽收敛门限
    max_iter: int = 100000,       # 提高迭代上限
    random_state: int = 42
) -> Tuple[List[str], float, sm.regression.linear_model.RegressionResultsWrapper]:
    """LASSO 标准化 + LassoCV 选 λ, 入模变量用原尺度做一次 OLS 以算 AIC/BIC。"""
    # 小样本时自适应CV折数，避免某些fold太小
    n = len(y)
    cv_eff = min(cv, max(3, n // 5))  # 至少3折，最多≈n/5折

    scaler = StandardScaler()
    X_std = scaler.fit_transform(X.values)

    if alphas is None:
        # 扩宽 λ 搜索范围，利于收敛（包含更强惩罚）
        alphas = np.logspace(-4, 2, 80)

    lasso_cv = LassoCV(
        alphas=alphas,
        cv=cv_eff,
        random_state=random_state,
        max_iter=max_iter,
        tol=tol,
        n_jobs=-1
    )
    lasso_cv.fit(X_std, y.values)

    coefs = lasso_cv.coef_
    selected = [col for col, c in zip(X.columns, coefs) if abs(c) > 1e-8]

    if len(selected) == 0:
        model = ols_fit(y, X.iloc[:, :0])  # 只有截距
    else:
        model = ols_fit(y, X[selected])

    return selected, float(lasso_cv.alpha_), model


# ============== 岭回归（GCV 选 λ）+ 有效自由度的 AIC/BIC ==============

def ridge_fit_with_ic(y: pd.Series, X: pd.DataFrame,
                      alphas: np.ndarray = None) -> Tuple[float, float, float, int]:
    """
    标准化X，RidgeCV(GCV/LOO)选alpha，返回 (alpha, AIC, BIC, df_eff_rounded)
    AIC/BIC 基于 ridge 残差 + 有效自由度 df_eff（再+1个截距）。
    """
    if alphas is None:
        alphas = np.logspace(-4, 4, 60)

    scaler = StandardScaler()
    X_std = scaler.fit_transform(X.values)
    y_vec = y.values

    # 从 sklearn 1.5 起不再使用 store_cv_values；默认即为 GCV/LOO
    ridge_cv = RidgeCV(alphas=alphas)
    ridge_cv.fit(X_std, y_vec)
    alpha = float(ridge_cv.alpha_)

    ridge = Ridge(alpha=alpha, fit_intercept=True)
    ridge.fit(X_std, y_vec)
    y_hat = ridge.predict(X_std)
    resid = y_vec - y_hat
    rss = float(np.sum(resid ** 2))
    n = len(y_vec)

    XtX = X_std.T @ X_std
    p = XtX.shape[0]
    inv_term = np.linalg.inv(XtX + alpha * np.eye(p))
    df_eff = np.trace(XtX @ inv_term)          # 不含截距
    k_eff = df_eff + 1.0                       # + 截距

    aic, bic = aic_bic_from_rss(n=n, rss=rss, k=k_eff)
    return alpha, aic, bic, int(round(df_eff))


# ============== 主流程：MBB 重采样 + 三模型拟合 ==============

def run_robustness_for_category(category: str,
                                selling_price: pd.DataFrame,
                                wholesale_price: pd.DataFrame,
                                sales_volume: pd.DataFrame,
                                r_list: List[float],
                                B: int) -> pd.DataFrame:
    """
    对单一 category, 按 r_list 做 MBB 重采样(B次)，在每次抽样上跑 三方法，
    返回收集的结果DataFrame。
    """
    y_full, X_full = build_design_matrices(selling_price, wholesale_price, sales_volume, category)
    n_full = len(y_full)
    if n_full < 10:
        raise ValueError(f"{category}: 样本太少（{n_full}），无法进行稳健性重采样。")

    # 建议块长
    L = suggest_block_len(n_full)

    rows = []
    for r in r_list:
        target_len = int(np.ceil(r * n_full))
        for b in range(1, B + 1):
            # 生成 MBB 索引（长度 target_len）
            idx = mbb_indices(T=n_full, target_len=target_len, block_len=L)

            y_s = y_full.iloc[idx].reset_index(drop=True)
            X_s = X_full.iloc[idx, :].reset_index(drop=True)
            n_s = len(y_s)

            # ========== 逐步回归（BIC） ==========
            try:
                selected_sw, model_sw = stepwise_bic(y_s, X_s)
                rss_sw = float(np.sum(model_sw.resid ** 2))
                k_sw = int(model_sw.df_model + 1)  # 含截距
                aic_sw, bic_sw = aic_bic_from_rss(n=n_s, rss=rss_sw, k=k_sw)

                rows.append({
                    "category": category,
                    "method": "Stepwise(BIC)",
                    "r": r,
                    "rep": b,
                    "n_sample": n_s,
                    "block_len": L,
                    "lambda_or_alpha": np.nan,
                    "model_size": len(selected_sw) if len(selected_sw) > 0 else 0,
                    "AIC": aic_sw,
                    "BIC": bic_sw,
                    "selected_vars": "; ".join(selected_sw) if len(selected_sw) else "(intercept only)"
                })
            except Exception as e:
                rows.append({
                    "category": category,
                    "method": "Stepwise(BIC)",
                    "r": r,
                    "rep": b,
                    "n_sample": n_s,
                    "block_len": L,
                    "lambda_or_alpha": np.nan,
                    "model_size": np.nan,
                    "AIC": np.nan,
                    "BIC": np.nan,
                    "selected_vars": f"ERROR: {e}"
                })

            # ========== LASSO + Post-OLS ==========
            try:
                selected_lasso, alpha_lasso, model_lasso = lasso_post_ols(y_s, X_s)
                rss_ls = float(np.sum(model_lasso.resid ** 2))
                k_ls = int(model_lasso.df_model + 1)  # 含截距
                aic_ls, bic_ls = aic_bic_from_rss(n=n_s, rss=rss_ls, k=k_ls)

                rows.append({
                    "category": category,
                    "method": "LASSO→Post-OLS",
                    "r": r,
                    "rep": b,
                    "n_sample": n_s,
                    "block_len": L,
                    "lambda_or_alpha": alpha_lasso,
                    "model_size": len(selected_lasso),
                    "AIC": aic_ls,
                    "BIC": bic_ls,
                    "selected_vars": "; ".join(selected_lasso) if len(selected_lasso) else "(intercept only)"
                })
            except Exception as e:
                rows.append({
                    "category": category,
                    "method": "LASSO→Post-OLS",
                    "r": r,
                    "rep": b,
                    "n_sample": n_s,
                    "block_len": L,
                    "lambda_or_alpha": np.nan,
                    "model_size": np.nan,
                    "AIC": np.nan,
                    "BIC": np.nan,
                    "selected_vars": f"ERROR: {e}"
                })

            # ========== 岭回归 (GCV) + 有效自由度IC ==========
            try:
                alpha_rg, aic_rg, bic_rg, df_eff = ridge_fit_with_ic(y_s, X_s)
                rows.append({
                    "category": category,
                    "method": "Ridge(GCV, df_eff-IC)",
                    "r": r,
                    "rep": b,
                    "n_sample": n_s,
                    "block_len": L,
                    "lambda_or_alpha": alpha_rg,
                    "model_size": df_eff,  # 把有效自由度作为“模型复杂度”指标
                    "AIC": aic_rg,
                    "BIC": bic_rg,
                    "selected_vars": "(ridge; no sparse set)"
                })
            except Exception as e:
                rows.append({
                    "category": category,
                    "method": "Ridge(GCV, df_eff-IC)",
                    "r": r,
                    "rep": b,
                    "n_sample": n_s,
                    "block_len": L,
                    "lambda_or_alpha": np.nan,
                    "model_size": np.nan,
                    "AIC": np.nan,
                    "BIC": np.nan,
                    "selected_vars": f"ERROR: {e}"
                })

    return pd.DataFrame(rows)

# ============== 主执行 ==============

def main():
    # 读取数据
    selling_price = pd.read_excel(DATA_FILE, sheet_name=SELLING_PRICE_SHEET)
    wholesale_price = pd.read_excel(DATA_FILE, sheet_name=WHOLESALE_PRICE_SHEET)
    sales_volume   = pd.read_excel(DATA_FILE, sheet_name=SALES_VOLUME_SHEET)

    # 结果写入 Excel：每个品类一个 sheet
    with pd.ExcelWriter(OUTPUT_EXCEL, engine="openpyxl") as writer:
        for cat in CATEGORIES:
            print(f"=== {cat}: 开始 MBB 重采样与三模型拟合 ===")
            df_cat = run_robustness_for_category(
                category=cat,
                selling_price=selling_price,
                wholesale_price=wholesale_price,
                sales_volume=sales_volume,
                r_list=R_LIST,
                B=B
            )
            # 排序一下输出：方法->比例->rep
            df_cat = df_cat.sort_values(["method", "r", "rep"]).reset_index(drop=True)
            df_cat.to_excel(writer, sheet_name=cat[:31], index=False)  # sheet名<=31字符
            print(f"=== {cat}: 完成，写入Excel工作表《{cat[:31]}》 ===")

    print(f"\n✅ 稳健性抽样全部完成，结果已写入：{os.path.abspath(OUTPUT_EXCEL)}")
    print("  每一行是一条重采样结果，含方法/比例/重复编号/AIC/BIC/模型大小/超参数与入模变量。")
    print("  你可以直接按比例与方法做 AIC/BIC 的中位数与IQR汇总，画箱线图即可。")

if __name__ == "__main__":
    main()
