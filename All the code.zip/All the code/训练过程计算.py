import pandas as pd
import glob
import os
import numpy as np

# 设置基础路径
base_path = r'C:\Users\15549\Desktop\CurvNetAttack-main\Other\RAIRO-Operations Research\5\kan ✔\kan two threeyear'

# 六类蔬菜
veggie_list = ['花菜类', '花叶类', '辣椒类', '茄类', '食用菌', '水生根茎类']

for veggie in veggie_list:
    pattern = os.path.join(base_path, f"sales_{veggie}_KAN_LSTM_5fold_average_threeyear_第*.xlsx")
    files = sorted(glob.glob(pattern))

    if not files:
        print(f"⚠️ 未找到 {veggie} 类文件，跳过。")
        continue

    all_runs = []

    for file in files:
        try:
            df = pd.read_excel(file, sheet_name='未来预测均值')
        except Exception as e:
            print(f"❌ 无法读取 {file}：{e}")
            continue

        # 重命名列为本次运行文件名
        df.rename(columns={'未来预测_均值': os.path.basename(file)}, inplace=True)
        all_runs.append(df)

    # 合并10次运行（按行索引自动对齐）
    merged = pd.concat(all_runs, axis=1)

    # 计算每一轮迭代的平均训练损失
    merged['平均预测值'] = merged.mean(axis=1)

    # 添加迭代轮次列
    merged.insert(0, '预测步', np.arange(1, len(merged) + 1))

    # 只保留两列：迭代轮次 + 平均训练损失
    result = merged[['预测步', '平均预测值']]

    # 输出结果
    output_path = os.path.join(base_path, f'sales_{veggie}_训练损失平均曲线.xlsx')
    result.to_excel(output_path, index=False)

    print(f"✅ {veggie} 类训练损失曲线计算完成，结果保存至：{output_path}")

print("\n🎯 六类蔬菜平均训练损失曲线全部生成完成！")
