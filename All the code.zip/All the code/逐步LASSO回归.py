import pandas as pd
import numpy as np
import statsmodels.api as sm

# ===================== 数据读取 =====================
data_file = r'C:\Users\15549\Desktop\问题一合并后的数据(仅供参考) - 副本.xlsx'
selling_price_sheet = "销售单价"
wholesale_price_sheet = "批发价格"
sales_volume_sheet = "销量"

selling_price = pd.read_excel(data_file, sheet_name=selling_price_sheet)
wholesale_price = pd.read_excel(data_file, sheet_name=wholesale_price_sheet)
sales_volume = pd.read_excel(data_file, sheet_name=sales_volume_sheet)

categories = ['Cauliflower', 'Leafy Greens', 'Peppers', 'Solanaceous Vegetables', 'Mushrooms', 'Aquatic Roots and Tubers']

# ===================== 逐步回归（BIC，双向） =====================
def fit_ols(X, y):
    Xc = sm.add_constant(X, has_constant='add')
    model = sm.OLS(y, Xc).fit()
    return model

def stepwise_bic(X, y, max_iter=200):
    """
    双向逐步回归（前进+后退），以 BIC 为准则。
    起点：仅截距；终止：没有进入/剔除能进一步降低 BIC。
    返回：最终 OLS 模型对象、特征列表
    """
    # 可用的全部候选
    candidates = list(X.columns)
    selected = []  # 当前入模集合
    current_model = fit_ols(X[selected] if selected else pd.DataFrame(index=X.index), y)
    current_bic = current_model.bic

    improved = True
    it = 0
    while improved and it < max_iter:
        it += 1
        improved = False

        # ---------- 前进一步：尝试加入一个未入模变量 ----------
        remaining = [v for v in candidates if v not in selected]
        best_add, best_add_bic, best_add_model = None, np.inf, None
        for var in remaining:
            trial_vars = selected + [var]
            try:
                m = fit_ols(X[trial_vars], y)
                if m.bic < best_add_bic:
                    best_add_bic, best_add_model, best_add = m.bic, m, var
            except Exception:
                continue

        # 如果加入最优变量能改进 BIC，则接受
        if best_add_model is not None and best_add_bic < current_bic - 1e-12:
            selected.append(best_add)
            current_bic = best_add_bic
            current_model = best_add_model
            improved = True

        # ---------- 后退一步：在已入模集合中尝试剔除一个变量 ----------
        if selected:
            best_drop, best_drop_bic, best_drop_model = None, current_bic, None
            for var in list(selected):
                trial_vars = [v for v in selected if v != var]
                try:
                    m = fit_ols(X[trial_vars] if trial_vars else pd.DataFrame(index=X.index), y)
                    if m.bic < best_drop_bic - 1e-12:
                        best_drop_bic, best_drop_model, best_drop = m.bic, m, var
                except Exception:
                    continue

            # 如果剔除能进一步改进 BIC，则接受
            if best_drop_model is not None and best_drop_bic < current_bic - 1e-12:
                selected.remove(best_drop)
                current_bic = best_drop_bic
                current_model = best_drop_model
                improved = True

    return current_model, selected

# ===================== 主循环：每个品类做一次逐步回归，并打印 F 与 R2 =====================
for category in categories:
    print(f"\n===== {category}：逐步回归（BIC，双向） =====")

    # 因变量（对数）
    y = np.log(sales_volume[category])

    # 自变量：补货价*加成率、其他品类的售价与销量（对数）
    X = pd.DataFrame()
    X['Wholesale Price * Markup'] = np.log(wholesale_price[category] * (1 + selling_price[category]))
    for other_category in categories:
        if other_category != category:
            X[f'Selling Price ({other_category})'] = np.log(selling_price[other_category])
            X[f'Sales Volume ({other_category})'] = np.log(sales_volume[other_category])

    # 处理可能的 ±inf/缺失（如有非正数）
    Xy = pd.concat([X, y.rename('y')], axis=1)
    Xy = Xy.replace([np.inf, -np.inf], np.nan).dropna()
    X = Xy.drop(columns=['y'])
    y = Xy['y']

    # 逐步回归
    model, selected_features = stepwise_bic(X, y)

    # 打印结果：最终模型的 F 与 R^2（保留三位小数）
    f_stat = float(model.fvalue) if model.fvalue is not None else np.nan
    r2 = float(model.rsquared)
    print(f"入模变量：{selected_features if selected_features else '仅常数项'}")
    print(f"F-statistic: {f_stat:.3f}    R^2: {r2:.3f}")
