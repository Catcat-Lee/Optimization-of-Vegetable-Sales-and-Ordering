# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd

# ========= 输入与输出路径 =========
INPUT_XLSX = r"C:\Users\15549\Desktop\CurvNetAttack-main\Other\RAIRO-Operations Research\robustness_MBB_AIC_BIC.xlsx"
OUTPUT_XLSX = r"C:\Users\15549\Desktop\CurvNetAttack-main\Other\RAIRO-Operations Research\robustness_IC_summary.xlsx"

# 映射一下方法名，列名更简洁（你也可以保留原名）
METHOD_MAP = {
    "LASSO→Post-OLS": "LASSO",
    "Stepwise(BIC)": "STEPWISE",
    "Ridge(GCV, df_eff-IC)": "RIDGE",
}

# 列顺序：方法顺序与比例顺序
METHOD_ORDER = ["STEPWISE", "LASSO", "RIDGE"]
R_ORDER = [0.5, 0.7, 1.0]

def build_label(method_raw: str, r: float) -> str:
    m = METHOD_MAP.get(method_raw, method_raw)
    # 把r格式化成去掉多余小数（0.1/0.5/1.0）
    r_str = f"{r:.1f}"
    return f"{m}_{r_str}"

def sort_columns(cols):
    """按 METHOD_ORDER 与 R_ORDER 对列（形如 'LASSO_0.1'）排序。"""
    def key_fn(col):
        try:
            m, r_str = col.split("_", 1)
            r_val = float(r_str)
        except Exception:
            m, r_val = col, 999
        m_idx = METHOD_ORDER.index(m) if m in METHOD_ORDER else 999
        r_idx = R_ORDER.index(r_val) if r_val in R_ORDER else 999
        return (m_idx, r_idx, col)
    return sorted(cols, key=key_fn)

def make_pivot(df_cat: pd.DataFrame, value_col: str) -> pd.DataFrame:
    """构造 AIC/BIC 透视表：index=rep, columns=方法_比例, values=AIC/BIC。"""
    # 只保留需要的列，去掉报错行
    df = df_cat.loc[:, ["method", "r", "rep", value_col]].copy()
    df = df[df[value_col].notna()]
    # 生成列标签
    df["label"] = [build_label(m, r) for m, r in zip(df["method"], df["r"])]
    # 透视
    pv = df.pivot_table(index="rep", columns="label", values=value_col, aggfunc="first")
    # 排序列
    pv = pv.reindex(columns=sort_columns(list(pv.columns)))
    pv = pv.sort_index()
    return pv

def main():
    # 读入整个工作簿（每个品类一个sheet）
    all_sheets = pd.read_excel(INPUT_XLSX, sheet_name=None)

    # 写出整理后的工作簿：每个品类一个sheet（含AIC表与BIC表）
    with pd.ExcelWriter(OUTPUT_XLSX, engine="openpyxl") as writer:
        for sheet_name, df_cat in all_sheets.items():
            # 基本字段存在性检查
            need_cols = {"category", "method", "r", "rep", "AIC", "BIC"}
            missing = need_cols.difference(df_cat.columns)
            if missing:
                print(f"[警告] 工作表《{sheet_name}》缺少字段：{missing}，将跳过。")
                continue

            # 构造AIC与BIC透视表
            aic_pv = make_pivot(df_cat, "AIC")
            bic_pv = make_pivot(df_cat, "BIC")

            # 写入同一sheet：AIC表在上，BIC表在下
            start_row = 0
            # 标题与AIC
            title_aic = pd.DataFrame({"": [f"{sheet_name} — AIC（列=方法_比例，行=rep）"]})
            title_aic.to_excel(writer, sheet_name=sheet_name[:31], index=False, header=False, startrow=start_row)
            aic_pv.to_excel(writer, sheet_name=sheet_name[:31], startrow=start_row + 1)
            # 空两行
            start_row = start_row + 2 + len(aic_pv) + 1
            # 标题与BIC
            title_bic = pd.DataFrame({"": [f"{sheet_name} — BIC（列=方法_比例，行=rep）"]})
            title_bic.to_excel(writer, sheet_name=sheet_name[:31], index=False, header=False, startrow=start_row)
            bic_pv.to_excel(writer, sheet_name=sheet_name[:31], startrow=start_row + 1)

    print(f"✅ 已生成整理后的Excel：{OUTPUT_XLSX}")
    print("   每个品类一个sheet；先是AIC透视表，再是BIC透视表。列名形如 LASSO_0.1 / RIDGE_1.0 / STEPWISE_0.5。")

if __name__ == "__main__":
    main()
