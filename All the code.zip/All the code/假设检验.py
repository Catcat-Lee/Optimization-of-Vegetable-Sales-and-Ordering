import numpy as np
import scipy.stats as stats
import pandas as pd

# 模型的均值和标准差 (销量预测)
models = ['KAN-LSTM', 'LSTM', 'xLSTM', 'TCN', 'Transformer', 'CNN-Transformer']
time_windows = [365, 730, 1095]

# 销量预测均值和标准差 (表3)
kan_lstm_sales_mean = {365: 0.8858, 730: 0.9447, 1095: 0.9585}
kan_lstm_sales_std = {365: 0.0492, 730: 0.0316, 1095: 0.0289}

other_models_sales_mean = {
    'LSTM': {365: 0.6221, 730: 0.6943, 1095: 0.7362},
    'xLSTM': {365: 0.8090, 730: 0.7356, 1095: 0.7630},
    'TCN': {365: 0.7856, 730: 0.8114, 1095: 0.8207},
    'Transformer': {365: 0.7369, 730: 0.7669, 1095: 0.8244},
    'CNN-Transformer': {365: 0.7591, 730: 0.8237, 1095: 0.8535}
}

other_models_sales_std = {
    'LSTM': {365: 0.0525, 730: 0.0527, 1095: 0.0613},
    'xLSTM': {365: 0.0655, 730: 0.0638, 1095: 0.0705},
    'TCN': {365: 0.0642, 730: 0.0574, 1095: 0.0652},
    'Transformer': {365: 0.0693, 730: 0.0592, 1095: 0.0697},
    'CNN-Transformer': {365: 0.0614, 730: 0.0681, 1095: 0.0669}
}

# 补货价格预测均值和标准差 (表4)
kan_lstm_price_mean = {365: 0.8935, 730: 0.9069, 1095: 0.9191}
kan_lstm_price_std = {365: 0.0472, 730: 0.0360, 1095: 0.0370}

other_models_price_mean = {
    'LSTM': {365: 0.6937, 730: 0.7416, 1095: 0.7098},
    'xLSTM': {365: 0.7820, 730: 0.7273, 1095: 0.7094},
    'TCN': {365: 0.8686, 730: 0.8732, 1095: 0.8540},
    'Transformer': {365: 0.7252, 730: 0.7333, 1095: 0.7501},
    'CNN-Transformer': {365: 0.7320, 730: 0.7508, 1095: 0.7949}
}

other_models_price_std = {
    'LSTM': {365: 0.0684, 730: 0.0637, 1095: 0.0767},
    'xLSTM': {365: 0.0790, 730: 0.0699, 1095: 0.0699},
    'TCN': {365: 0.0643, 730: 0.0751, 1095: 0.0696},
    'Transformer': {365: 0.0714, 730: 0.0710, 1095: 0.0634},
    'CNN-Transformer': {365: 0.0798, 730: 0.0702, 1095: 0.0774}
}

# 样本大小
n = 60  # 每个模型的实验次数


# 配对t检验函数
def paired_t_test(mean_1, mean_2, std_1, std_2, n):
    # 计算标准误差
    se = np.sqrt((std_1 ** 2 + std_2 ** 2) / n)
    # 计算t值
    t_stat = (mean_1 - mean_2) / se
    # 计算自由度
    df = n - 1
    # 计算p值
    p_value = stats.t.sf(np.abs(t_stat), df) * 2  # 双尾检验
    return t_stat, p_value


# 结果存储
results_sales = []
results_price = []

# 对每个时间窗口进行假设检验
for time_window in time_windows:
    for model_name, model_mean in other_models_sales_mean.items():
        kan_lstm_sales_mean_value = kan_lstm_sales_mean[time_window]
        kan_lstm_sales_std_value = kan_lstm_sales_std[time_window]
        model_sales_mean_value = model_mean[time_window]
        model_sales_std_value = other_models_sales_std[model_name][time_window]

        # 对KAN-LSTM与当前模型进行配对t检验（销量预测）
        t_stat, p_value = paired_t_test(kan_lstm_sales_mean_value, model_sales_mean_value, kan_lstm_sales_std_value,
                                        model_sales_std_value, n)
        results_sales.append({
            'Model': model_name,
            'Time Window': time_window,
            't-statistic': t_stat,
            'p-value': p_value
        })

    for model_name, model_mean in other_models_price_mean.items():
        kan_lstm_price_mean_value = kan_lstm_price_mean[time_window]
        kan_lstm_price_std_value = kan_lstm_price_std[time_window]
        model_price_mean_value = model_mean[time_window]
        model_price_std_value = other_models_price_std[model_name][time_window]

        # 对KAN-LSTM与当前模型进行配对t检验（补货价格预测）
        t_stat, p_value = paired_t_test(kan_lstm_price_mean_value, model_price_mean_value, kan_lstm_price_std_value,
                                        model_price_std_value, n)
        results_price.append({
            'Model': model_name,
            'Time Window': time_window,
            't-statistic': t_stat,
            'p-value': p_value
        })

# 将结果转换为DataFrame
results_sales_df = pd.DataFrame(results_sales)
results_price_df = pd.DataFrame(results_price)

# 将结果保存到Excel文件
with pd.ExcelWriter('hypothesis_test_results.xlsx') as writer:
    results_sales_df.to_excel(writer, sheet_name='Sales Prediction', index=False)
    results_price_df.to_excel(writer, sheet_name='Restocking Price Prediction', index=False)

# 打印结果
print("Sales Prediction Hypothesis Test Results:")
print(results_sales_df)

print("\nRestocking Price Prediction Hypothesis Test Results:")
print(results_price_df)
