import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.preprocessing import MinMaxScaler
import torch.optim as optim
from sklearn.model_selection import TimeSeriesSplit
import matplotlib.pyplot as plt
import os

# ------------------ 数据读取 ------------------
file_path = r'补货价格_threeyear_filled.xlsx'
data = pd.read_excel(file_path)
data['销售日期'] = pd.to_datetime(data['销售日期'])
data.set_index('销售日期', inplace=True)
data = data[['花菜类']]  # 只选一个品类示例

# ------------------ 模型定义 ------------------
class KANLSTMModel(nn.Module):
    def __init__(self, input_size=1, hidden_size=6, output_size=1, num_layers=1):
        super(KANLSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.kernel_activation = nn.Linear(hidden_size, hidden_size)
        self.fc1 = nn.Linear(hidden_size, 7)
        self.fc2 = nn.Linear(7, output_size)

    def forward(self, x):
        lstm_out, _ = self.lstm(x)
        activated_out = torch.sigmoid(self.kernel_activation(lstm_out))
        out_residual = lstm_out + activated_out
        out = self.fc1(out_residual)
        out = torch.relu(out)
        out = self.fc2(out)
        return out

# ------------------ 五折交叉验证 ------------------
tscv = TimeSeriesSplit(n_splits=5)
all_fold_train_losses = []  # 每折训练集损失
all_fold_val_losses = []    # 每折验证集损失

for column in data.columns:
    print(f"\n===== 5-Fold TimeSeries CV for {column} =====")
    y_full = data[[column]].values

    for fold, (train_idx, test_idx) in enumerate(tscv.split(y_full), start=1):
        print(f"\n--- Fold {fold} ---")

        train = data.iloc[train_idx]
        test = data.iloc[test_idx]

        # 归一化
        scaler = MinMaxScaler()
        train_scaled = scaler.fit_transform(train)
        test_scaled = scaler.transform(test)

        # 转为 tensor
        train_tensor = torch.tensor(train_scaled, dtype=torch.float32).unsqueeze(0)
        test_tensor = torch.tensor(test_scaled, dtype=torch.float32).unsqueeze(0)

        # 模型定义
        model = KANLSTMModel(input_size=1, hidden_size=6, output_size=1, num_layers=3)
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.007)

        train_losses = []
        val_losses = []

        for epoch in range(600):
            # ---- 训练阶段 ----
            model.train()
            optimizer.zero_grad()
            outputs = model(train_tensor)
            loss = criterion(outputs.squeeze(), train_tensor.squeeze())
            loss.backward()
            optimizer.step()

            # ---- 验证阶段 ----
            model.eval()
            with torch.no_grad():
                val_outputs = model(test_tensor)
                val_loss = criterion(val_outputs.squeeze(), test_tensor.squeeze())

            train_losses.append(loss.item())
            val_losses.append(val_loss.item())

            if (epoch + 1) % 100 == 0:
                print(f"Epoch [{epoch+1}/600] | Fold {fold} | Train Loss: {loss.item():.6f} | Val Loss: {val_loss.item():.6f}")

        all_fold_train_losses.append(train_losses)
        all_fold_val_losses.append(val_losses)

# ------------------ 计算平均与标准差 ------------------
all_fold_train_losses = np.array(all_fold_train_losses)  # (5, 600)
all_fold_val_losses = np.array(all_fold_val_losses)      # (5, 600)

mean_train_curve = all_fold_train_losses.mean(axis=0)
mean_val_curve = all_fold_val_losses.mean(axis=0)

std_train_curve = all_fold_train_losses.std(axis=0, ddof=1)
std_val_curve = all_fold_val_losses.std(axis=0, ddof=1)

# ------------------ 保存结果 ------------------
output_file = f"补货价格_{column}_KANLSTM_train_val_loss.xlsx"
with pd.ExcelWriter(output_file) as writer:
    pd.DataFrame({
        'Epoch': np.arange(1, len(mean_train_curve) + 1),
        'Training_Loss_Mean': mean_train_curve,
        'Training_Loss_Std': std_train_curve
    }).to_excel(writer, sheet_name='训练阶段平均损失曲线', index=False)

    pd.DataFrame({
        'Epoch': np.arange(1, len(mean_val_curve) + 1),
        'Validation_Loss_Mean': mean_val_curve,
        'Validation_Loss_Std': std_val_curve
    }).to_excel(writer, sheet_name='五折交叉验证平均损失曲线', index=False)

print(f"\n✅ 已保存训练与验证损失曲线数据至：{output_file}")

# ------------------ 绘图部分 ------------------
plt.figure(figsize=(8, 5))
epochs = np.arange(1, len(mean_train_curve) + 1)

plt.plot(epochs, mean_train_curve, label='Training Loss', color='blue')
plt.fill_between(epochs, mean_train_curve - std_train_curve, mean_train_curve + std_train_curve,
                 color='blue', alpha=0.2)

plt.plot(epochs, mean_val_curve, label='Validation Loss', color='orange')
plt.fill_between(epochs, mean_val_curve - std_val_curve, mean_val_curve + std_val_curve,
                 color='orange', alpha=0.2)

plt.title('KAN-LSTM 五折交叉验证平均损失曲线', fontsize=14)
plt.xlabel('Epoch', fontsize=12)
plt.ylabel('Loss (MSE)', fontsize=12)
plt.legend()
plt.grid(True)
plt.tight_layout()

# 保存图像
plot_path = os.path.splitext(output_file)[0] + "_loss_curve.png"
plt.savefig(plot_path, dpi=300)
plt.show()

print(f"📉 图像已保存至：{plot_path}")
