import os
import pandas as pd
import numpy as np
import re

# 设置文件夹路径
folder_path = r"C:\Users\15549\Desktop\CurvNetAttack-main\Other\RAIRO-Operations Research\5\xlstm ✔"  # 请修改为实际文件夹路径

# 定义指标名称
metrics = ['R2', 'MAE', 'sMAPE', 'MASE(m=30)', 'MAPE', 'MPE']

# 定义存储文件名符合条件的文件的字典
files_to_process = {}

# 扫描文件夹，读取Excel文件
for filename in os.listdir(folder_path):
    if filename.endswith(".xlsx"):  # 确保是Excel文件
        # 正则表达式匹配类似 "price_花菜类_CNN_Transformer_5fold_average_oneyear_第01次运行.xlsx" 的文件名
        match = re.match(r"price_.*_xLSTM_5fold_average_oneyear_第(\d{2})次运行.xlsx", filename)

        if match:
            run_number = int(match.group(1))  # 获取运行次数（01到10）
            if 1 <= run_number <= 10:  # 只处理第1到第10次运行
                # 使用运行次数作为key存储文件路径
                if run_number not in files_to_process:
                    files_to_process[run_number] = []
                files_to_process[run_number].append(os.path.join(folder_path, filename))

# 初始化结果存储
results = {metric: [] for metric in metrics}  # 直接存储均值数据
files_with_na = []  # 用于存储包含空值的文件名

# 按运行次数（1到10次）读取文件并提取数据
for run_number, files in files_to_process.items():
    for file_path in files:
        print(f"Processing file: {file_path}")  # 调试输出，查看当前正在处理的文件
        try:
            # 读取Excel文件
            df = pd.read_excel(file_path, sheet_name="5折平均指标")

            # 打印工作表的前几行以确保数据被正确读取
            print(f"Data preview from {file_path}:")
            print(df.head())  # 输出前几行数据，检查数据是否被正确读取

            # 检查工作表中是否包含指标列
            for metric in metrics:
                if metric in df['指标'].values:
                    # 提取测试集均值
                    test_mean = df[df['指标'] == metric]['测试集_均值'].values[0]

                    # 检查是否有空值
                    if pd.isna(test_mean):
                        files_with_na.append(file_path)  # 记录包含空值的文件

                    # 将数据添加到对应的结果列表中
                    results[metric].append(test_mean)
        except Exception as e:
            print(f"Error processing file {file_path}: {e}")

# 计算每个指标的测试集均值的均值和标准差
final_results = {}
for metric, means in results.items():
    if means:  # 确保有数据
        mean_of_means = np.mean(means)  # 计算均值
        std_of_means = np.std(means)  # 计算标准差
        final_results[metric] = {'mean_of_means': mean_of_means, 'std_of_means': std_of_means}
    else:
        final_results[metric] = {'mean_of_means': np.nan, 'std_of_means': np.nan}

# 将结果保存为一个新的Excel文件
output_df = pd.DataFrame(final_results).T  # 转置结果，使每个指标为一行
output_df.reset_index(inplace=True)
output_df.columns = ['指标', '测试集均值的均值', '测试集均值的标准差']

# 保存到新的Excel文件
output_path = r"C:\Users\15549\Desktop\CurvNetAttack-main\Other\RAIRO-Operations Research\5\数据储存\prices_xLSTM_Oneyear.xlsx"  # 输出文件名，可以根据需要修改
output_df.to_excel(output_path, index=False)

# 输出包含空值的文件路径
if files_with_na:
    print("以下文件包含空值：")
    for file in files_with_na:
        print(file)
else:
    print("没有文件包含空值。")

print(f"结果已保存到 {output_path}")
