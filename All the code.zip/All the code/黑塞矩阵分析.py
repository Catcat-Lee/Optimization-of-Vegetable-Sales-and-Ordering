import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# ====== 可配置部分 ======
np.random.seed(42)
num_trials = 100              # 采样次数
epsilon = 1e-3                # 数值差分步长
n = 2                         # 商品维度（=len(c)=len(h)=len(alpha)=len(beta)）

# 变量/参数的采样范围（你给的区间）
m_low, m_high = 0.1, 0.5
h_low, h_high = 0.05, 0.3
beta_low, beta_high = -2.0, 2.0
alpha_low, alpha_high = -2.0, 2.0

# 成本 c 可固定或随机；若你有实际 c_i 就填进去
c = np.array([5.0, 20.0])     # 示例：固定成本
# =======================

def objective_function(m, c, h, alpha, beta):
    """
    情况一（不含递归）： D_i = exp(alpha_i) * (c_i * (1+m_i)) ** (-beta_i)
    目标 = sum_i (c_i*m_i + h_i) * D_i
    返回标量
    """
    D = np.exp(alpha) * (c * (1.0 + m)) ** (-beta)
    profit = np.sum((c * m + h) * D)
    return profit

def hessian_central(f, m, c, h, alpha, beta, eps=1e-5):
    """
    中心差分 Hessian。注意 f 必须返回标量。
    """
    n = len(m)
    H = np.zeros((n, n))
    # 单位向量
    I = np.eye(n)

    for i in range(n):
        for j in range(n):
            # 四点式混合二阶差分
            fpp = f(m + eps*I[i] + eps*I[j], c, h, alpha, beta)
            fpm = f(m + eps*I[i] - eps*I[j], c, h, alpha, beta)
            fmp = f(m - eps*I[i] + eps*I[j], c, h, alpha, beta)
            fmm = f(m - eps*I[i] - eps*I[j], c, h, alpha, beta)
            H[i, j] = (fpp - fpm - fmp + fmm) / (4.0 * eps**2)
    return H

def classify_definiteness(H, tol=1e-8):
    eigvals = np.linalg.eigvals(H).real
    min_eig, max_eig = eigvals.min(), eigvals.max()
    if np.all(eigvals > tol):
        return "convex", min_eig, max_eig
    elif np.all(eigvals < -tol):
        return "concave", min_eig, max_eig
    else:
        return "indeterminate", min_eig, max_eig

# 统计量
counts = {"convex": 0, "concave": 0, "indeterminate": 0}
min_eigs, max_eigs, categories = [], [], []

for t in range(num_trials):
    # 随机采样一个点 & 参数（你也可以固定 h/alpha/beta，只随机 m）
    m = np.random.uniform(m_low, m_high, size=n)
    h = np.random.uniform(h_low, h_high, size=n)
    beta = np.random.uniform(beta_low, beta_high, size=n)
    alpha = np.random.uniform(alpha_low, alpha_high, size=n)

    # Hessian
    H = hessian_central(objective_function, m, c, h, alpha, beta, eps=epsilon)
    kind, mine, maxe = classify_definiteness(H)
    counts[kind] += 1
    min_eigs.append(mine)
    max_eigs.append(maxe)
    categories.append(kind)

# 输出汇总
total = float(num_trials)
print(f"Trials: {num_trials}")
print(f"Convex:         {counts['convex']} ({counts['convex']/total:.1%})")
print(f"Concave:        {counts['concave']} ({counts['concave']/total:.1%})")
print(f"Indeterminate:  {counts['indeterminate']} ({counts['indeterminate']/total:.1%})")
print(f"Min of min-eigs: {np.min(min_eigs):.6g}")
print(f"Max of min-eigs: {np.max(min_eigs):.6g}")
print(f"Min of max-eigs: {np.min(max_eigs):.6g}")
print(f"Max of max-eigs: {np.max(max_eigs):.6g}")

# ===== 可视化 =====

# 设置字体为 Times New Roman，并加粗坐标轴标签与标题，但不加粗坐标轴的数字
plt.rcParams.update({
    'font.family': 'Times New Roman',  # 设置字体
    'axes.labelweight': 'bold',       # 加粗坐标轴标签
    'axes.titlesize': 16,             # 设置标题字体大小
    'axes.labelsize': 14,             # 设置坐标轴标签字体大小
    'xtick.labelsize': 12,            # 设置X轴刻度字体大小
    'ytick.labelsize': 12             # 设置Y轴刻度字体大小
})

# 特征值分布：最小特征值 vs 最大特征值
plt.figure(figsize=(7, 4.5))
sns.scatterplot(x=min_eigs, y=max_eigs, hue=categories, palette={"convex": "green", "concave": "red", "indeterminate": "orange"})
plt.xlabel("Min Eigenvalue", fontsize=14, fontweight='bold')
plt.ylabel("Max Eigenvalue", fontsize=14, fontweight='bold')
plt.legend(title="Definiteness")
plt.grid(True)

# 保存为PDF文件
plt.savefig("hessian_eigenvalues_distribution.pdf", format="pdf")

# 显示图表
plt.show()
