import pandas as pd
import glob
import os
import numpy as np

# 设置基础路径
base_path = r'C:\Users\15549\Desktop\CurvNetAttack-main\Other\RAIRO-Operations Research\5\kan ✔\kan two threeyear'

# 六类蔬菜名称
veggie_list = ['花菜类', '花叶类', '辣椒类', '茄类', '食用菌', '水生根茎类']

# 95%置信区间 t 值（自由度 n-1 = 9, n=10）
t_value = 2.262
n = 10

for veggie in veggie_list:
    pattern = os.path.join(base_path, f"sales_{veggie}_KAN_LSTM_5fold_average_threeyear_第*.xlsx")
    files = sorted(glob.glob(pattern))

    if not files:
        print(f"⚠️ 未找到 {veggie} 类文件，跳过。")
        continue

    results = []

    for file in files:
        df = pd.read_excel(file, sheet_name='5折平均指标')
        df = df[['指标', '测试集_均值']].copy()
        df.rename(columns={'测试集_均值': os.path.basename(file)}, inplace=True)
        results.append(df)

    merged = results[0]
    for df in results[1:]:
        merged = pd.merge(merged, df, on='指标', how='outer')

    # 计算统计指标
    merged['平均值'] = merged.iloc[:, 1:].mean(axis=1)
    merged['标准差'] = merged.iloc[:, 1:].std(axis=1, ddof=1)
    merged['95%置信区间(±)'] = t_value * merged['标准差'] / np.sqrt(n)

    # 输出结果
    final = merged[['指标', '平均值', '标准差', '95%置信区间(±)']]
    output_path = os.path.join(base_path, f'sales_{veggie}_KAN_LSTM_5fold_average汇总_含置信区间.xlsx')
    final.to_excel(output_path, index=False)

    print(f"✅ {veggie} 类汇总完成，结果已保存到：{output_path}")

print("\n🎯 所有六类蔬菜已处理完成！")
