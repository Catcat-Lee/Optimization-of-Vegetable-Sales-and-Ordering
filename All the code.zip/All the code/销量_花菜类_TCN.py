import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.metrics import r2_score
from sklearn.preprocessing import MinMaxScaler
import torch.optim as optim
import matplotlib.pyplot as plt
from sklearn.model_selection import TimeSeriesSplit

# ------------------ 评估指标函数（保持不变） ------------------
EPS = 1e-8  # 防除零

def mae(y_true, y_pred):
    y_true = np.asarray(y_true).reshape(-1)
    y_pred = np.asarray(y_pred).reshape(-1)
    return float(np.mean(np.abs(y_true - y_pred)))

def smape(y_true, y_pred):
    y_true = np.asarray(y_true).reshape(-1)
    y_pred = np.asarray(y_pred).reshape(-1)
    return float(np.mean(200.0 * np.abs(y_pred - y_true) /
                         (np.abs(y_true) + np.abs(y_pred) + EPS)))

def mase(y_true, y_pred, m=30):
    """
    Mean Absolute Scaled Error with seasonal period m.
    缩放项：平均 |y_t - y_{t-m}|（在 y_true 上计算）
    """
    y_true = np.asarray(y_true).reshape(-1)
    y_pred = np.asarray(y_pred).reshape(-1)
    if len(y_true) <= m:
        scale = np.mean(np.abs(np.diff(y_true))) if len(y_true) > 1 else EPS
    else:
        scale = np.mean(np.abs(y_true[m:] - y_true[:-m]))
    return float(np.mean(np.abs(y_true - y_pred)) / (scale + EPS))

def mpe(y_true, y_pred):
    """Mean Percentage Error（带符号，衡量系统性偏差，单位：%）"""
    y_true = np.asarray(y_true).reshape(-1)
    y_pred = np.asarray(y_pred).reshape(-1)
    return float(np.mean((y_pred - y_true) / (np.abs(y_true) + EPS)) * 100.0)

def mean_std(arr):
    arr = list(arr)
    return (float(np.mean(arr)), float(np.std(arr, ddof=1)) if len(arr) > 1 else 0.0)

# ------------------ 数据读取（保持不变） ------------------
file_path = r'销量_threeyear_filled.xlsx'
data = pd.read_excel(file_path)
data['销售日期'] = pd.to_datetime(data['销售日期'])
data.set_index('销售日期', inplace=True)

# 只选择“花菜类”列
data = data[['花菜类']]

# ------------------ 模型定义：TCN（仅此改动） ------------------
class TemporalBlock(nn.Module):
    """
    两层因果空洞卷积 + 残差。保持时间长度不变（通过padding并裁剪）。
    """
    def __init__(self, n_inputs, n_outputs, kernel_size, dilation, dropout=0.0):
        super().__init__()
        padding = (kernel_size - 1) * dilation

        self.conv1 = nn.Conv1d(n_inputs, n_outputs, kernel_size,
                               padding=padding, dilation=dilation)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)

        self.conv2 = nn.Conv1d(n_outputs, n_outputs, kernel_size,
                               padding=padding, dilation=dilation)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout)

        # 若通道数不一致，用1x1卷积对残差进行投影
        self.downsample = nn.Conv1d(n_inputs, n_outputs, 1) if n_inputs != n_outputs else None
        self.init_weights()

    def init_weights(self):
        nn.init.kaiming_uniform_(self.conv1.weight, nonlinearity='relu')
        nn.init.zeros_(self.conv1.bias)
        nn.init.kaiming_uniform_(self.conv2.weight, nonlinearity='relu')
        nn.init.zeros_(self.conv2.bias)
        if self.downsample is not None:
            nn.init.kaiming_uniform_(self.downsample.weight, nonlinearity='linear')
            nn.init.zeros_(self.downsample.bias)

    def forward(self, x):
        # x: (B, C, T)
        out = self.conv1(x)
        out = out[:, :, :x.size(2)]  # 裁剪实现“因果”对齐，保持长度 T
        out = self.relu1(out)
        out = self.dropout1(out)

        out = self.conv2(out)
        out = out[:, :, :x.size(2)]
        out = self.relu2(out)
        out = self.dropout2(out)

        res = x if self.downsample is None else self.downsample(x)
        res = res[:, :, :x.size(2)]
        return out + res

class TCNModel(nn.Module):
    """
    轻量 TCN：
    - 将输入 (B, T, 1) 转为 (B, 1, T) 送入若干 TemporalBlock（num_layers 决定层数，dilations=1,2,4,...）
    - 通道数统一用 hidden_size
    - 输出转回 (B, T, hidden_size)，再接你原本的序列到序列全连接头 fc1(->7)+ReLU+fc2(->1)
    - 形状保持与原先一致：(B, T, 1)
    """
    def __init__(self, input_size=1, hidden_size=6, output_size=1, num_layers=1,
                 kernel_size=3, dropout=0.0):
        super().__init__()
        layers = []
        in_ch = input_size
        for i in range(num_layers):
            dilation = 2 ** i
            layers.append(TemporalBlock(in_ch, hidden_size, kernel_size, dilation, dropout))
            in_ch = hidden_size
        self.tcn = nn.Sequential(*layers)
        self.fc1 = nn.Linear(hidden_size, 7)
        self.fc2 = nn.Linear(7, output_size)

    def forward(self, x):
        # x: (B, T, 1) -> (B, 1, T)
        x_perm = x.transpose(1, 2)
        h = self.tcn(x_perm)                   # (B, hidden, T)
        h = h.transpose(1, 2)                  # (B, T, hidden)
        out = self.fc1(h)                      # (B, T, 7)
        out = torch.relu(out)
        out = self.fc2(out)                    # (B, T, 1)
        return out

# ------------------ 未来预测（保持不变） ------------------
def predict_future(model, last_sequence, steps, scaler):
    future_preds = []
    input_seq = last_sequence.copy()
    for _ in range(steps):
        input_tensor = torch.tensor(input_seq, dtype=torch.float32).unsqueeze(0).unsqueeze(-1)
        pred = model(input_tensor).detach().numpy()[-1, 0]  # 保持你的索引写法
        future_preds.append(pred)
        input_seq = np.append(input_seq, pred)[-len(last_sequence):]
    return scaler.inverse_transform(np.array(future_preds).reshape(-1, 1))

# ===== 5 折时序交叉验证（保持不变，仅模型类名替换） =====
tscv = TimeSeriesSplit(n_splits=5)

train_r2_list, train_mae_list, train_smape_list, train_mase_list, train_mape_list, train_mpe_list = [], [], [], [], [], []
test_r2_list,  test_mae_list,  test_smape_list,  test_mase_list,  test_mape_list,  test_mpe_list  = [], [], [], [], [], []
losses_all_folds = []           # 每折的 600 个 loss
future_all_folds = []           # 每折未来 15 步（反归一化后的数值）

for column in data.columns:
    print(f"\n===== 5-Fold TimeSeries CV for {column} =====")
    y_full = data[[column]].values  # (N,1)

    for fold, (train_idx, test_idx) in enumerate(tscv.split(y_full), start=1):
        print(f"\n--- Fold {fold} ---")
        train = pd.DataFrame(y_full[train_idx], index=data.index[train_idx], columns=[column])
        test  = pd.DataFrame(y_full[test_idx],  index=data.index[test_idx],  columns=[column])

        # 仅用当前折训练集拟合 scaler
        scaler = MinMaxScaler(feature_range=(0, 1))
        train_data = scaler.fit_transform(train[[column]].values.reshape(-1, 1))
        test_data  = scaler.transform(test[[column]].values.reshape(-1, 1))

        # (batch=1, seq_len, 1)
        train_tensor = torch.tensor(train_data, dtype=torch.float32).unsqueeze(0)
        test_tensor  = torch.tensor(test_data,  dtype=torch.float32).unsqueeze(0)

        # 模型 & 训练（仅将类名替换为 TCNModel，其余不变）
        model = TCNModel(input_size=1, hidden_size=6, output_size=1, num_layers=3, kernel_size=3, dropout=0.0)
        criterion = nn.MSELoss()
        optimizer = optim.Adam(model.parameters(), lr=0.001)

        losses = []
        model.train()
        for epoch in range(600):  # 固定 600 轮，便于折间做逐 epoch 平均
            optimizer.zero_grad()
            outputs = model(train_tensor)
            loss = criterion(outputs.squeeze(), train_tensor.squeeze())
            loss.backward()
            optimizer.step()
            losses.append(loss.item())
            if (epoch + 1) % 50 == 0:
                print(f"Epoch [{epoch + 1}/600], Loss: {loss.item():.6f}")

        losses_all_folds.append(losses)

        # 训练/测试预测（保持一致）
        model.eval()
        train_preds = model(train_tensor).detach().numpy().squeeze(0)
        train_preds = scaler.inverse_transform(train_preds)
        train_true  = scaler.inverse_transform(train_data)

        test_preds = model(test_tensor).detach().numpy().squeeze(0)
        test_preds = scaler.inverse_transform(test_preds)
        test_true  = scaler.inverse_transform(test_data)

        # ===== 指标（R2、MAE、sMAPE、MASE(m=30)、MAPE、MPE）=====
        train_r2    = r2_score(train_true, train_preds)
        train_mae_v = mae(train_true, train_preds)
        train_smape_v = smape(train_true, train_preds)
        train_mase_v = mase(train_true, train_preds, m=30)
        train_mape_v = float(np.mean(np.abs((train_true - train_preds) / (train_true + EPS))) * 100.0)
        train_mpe_v  = mpe(train_true, train_preds)

        test_r2     = r2_score(test_true, test_preds)
        test_mae_v  = mae(test_true, test_preds)
        test_smape_v = smape(test_true, test_preds)
        test_mase_v = mase(test_true, test_preds, m=30)
        test_mape_v = float(np.mean(np.abs((test_true - test_preds) / (test_true + EPS))) * 100.0)
        test_mpe_v  = mpe(test_true, test_preds)

        # 收集
        train_r2_list.append(train_r2)
        train_mae_list.append(train_mae_v)
        train_smape_list.append(train_smape_v)
        train_mase_list.append(train_mase_v)
        train_mape_list.append(train_mape_v)
        train_mpe_list.append(train_mpe_v)

        test_r2_list.append(test_r2)
        test_mae_list.append(test_mae_v)
        test_smape_list.append(test_smape_v)
        test_mase_list.append(test_mase_v)
        test_mape_list.append(test_mape_v)
        test_mpe_list.append(test_mpe_v)

        # 未来 15 步预测（保持不变）
        future_preds = predict_future(model, test_data.flatten(), steps=15, scaler=scaler)
        future_all_folds.append(future_preds.flatten())

    # ===== 计算 5 折均值与标准差 =====
    train_r2_mean,    train_r2_std    = mean_std(train_r2_list)
    train_mae_mean,   train_mae_std   = mean_std(train_mae_list)
    train_smape_mean, train_smape_std = mean_std(train_smape_list)
    train_mase_mean,  train_mase_std  = mean_std(train_mase_list)
    train_mape_mean,  train_mape_std  = mean_std(train_mape_list)
    train_mpe_mean,   train_mpe_std   = mean_std(train_mpe_list)

    test_r2_mean,     test_r2_std     = mean_std(test_r2_list)
    test_mae_mean,    test_mae_std    = mean_std(test_mae_list)
    test_smape_mean,  test_smape_std  = mean_std(test_smape_list)
    test_mase_mean,   test_mase_std   = mean_std(test_mase_list)
    test_mape_mean,   test_mape_std   = mean_std(test_mape_list)
    test_mpe_mean,    test_mpe_std    = mean_std(test_mpe_list)

    # 逐 epoch 训练损失的折均值（形状：600，取每个 epoch 在 5 折上的平均）
    losses_all_folds = np.array(losses_all_folds)   # (5, 600)
    mean_losses = losses_all_folds.mean(axis=0)     # (600,)

    # 未来 15 步预测的折均值
    future_all_folds = np.array(future_all_folds)   # (5, 15)
    mean_future = future_all_folds.mean(axis=0)     # (15,)

    # ===== 只保存一个“平均结果”的 Excel（文件名保持不变） =====
    output_file = f"销量_{column}_TCN_5fold_average.xlsx"
    with pd.ExcelWriter(output_file) as writer:
        pd.DataFrame({
            '指标': ['R2', 'MAE', 'sMAPE', 'MASE(m=30)', 'MAPE', 'MPE'],
            '训练集_均值':   [train_r2_mean, train_mae_mean, train_smape_mean, train_mase_mean, train_mape_mean, train_mpe_mean],
            '训练集_标准差': [train_r2_std,  train_mae_std,  train_smape_std,  train_mase_std,  train_mape_std,  train_mpe_std],
            '测试集_均值':   [test_r2_mean,  test_mae_mean,  test_smape_mean,  test_mase_mean,  test_mape_mean,  test_mpe_mean],
            '测试集_标准差': [test_r2_std,   test_mae_std,   test_smape_std,   test_mase_std,   test_mape_std,   test_mpe_std],
        }).to_excel(writer, sheet_name='5折平均指标', index=False)

        pd.DataFrame({'训练过程损失_均值': mean_losses}).to_excel(writer, sheet_name='训练损失均值', index=False)
        pd.DataFrame({'未来预测_均值': mean_future}).to_excel(writer, sheet_name='未来预测均值', index=False)

    print(f"\n平均结果已保存到：{output_file}")

print("\nAll CV (averaged) results are complete.")
